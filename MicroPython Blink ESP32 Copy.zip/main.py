from machine import Pin
from utime import sleep




print("Hello, ESP32!")

vermelho = Pin(15, Pin.OUT)
azul = Pin(12, Pin.OUT)

azul.value(0)
vermelho.value(0)

while True:
    digita_led = input("Digite (azul) ou (vermelho) ou pressione(f) para encerrar o sistema: ").lower().strip()

    if digita_led == "vermelho":
        vermelho.value(1)
        azul.value(0)
        sleep(1)
        print("LED Vermelho ligado!")

    elif digita_led == "azul":
        vermelho.value(0)
        azul.value(1) 
        sleep(1)
        print("LED Azul ligado!")

    elif digita_led == "f":
        print("Desligando ESP32.")
        sleep(0.8)
        print("Desligando ESP32..")
        sleep(0.8)
        print("Desligando ESP32...")
        sleep(0.3)
        vermelho.value(0)
        azul.value(0)
        sys.exit()
    
    else:
        print("Voce digitou:", digita_led)
        print("Erro: Use apenas 'azul' ou 'vermelho'")